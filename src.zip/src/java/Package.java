public class Package {
    private String eventName;
    private double eventPrice;
    private String hotelName;
    private double hotelPricePerNight;
    private String transportCompany;
    private double transportPrice;

    // Constructor
    public Package(String eventName, double eventPrice, String hotelName, double hotelPricePerNight, String transportCompany, double transportPrice) {
        this.eventName = eventName;
        this.eventPrice = eventPrice;
        this.hotelName = hotelName;
        this.hotelPricePerNight = hotelPricePerNight;
        this.transportCompany = transportCompany;
        this.transportPrice = transportPrice;
    }

    // Getters and Setters
    public String getEventName() { return eventName; }
    public double getEventPrice() { return eventPrice; }
    public String getHotelName() { return hotelName; }
    public double getHotelPricePerNight() { return hotelPricePerNight; }
    public String getTransportCompany() { return transportCompany; }
    public double getTransportPrice() { return transportPrice; }
}
