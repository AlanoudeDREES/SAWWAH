package Servlets;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

public class AvailablePackagesServlet extends HttpServlet {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/sawwah"; // Replace with your DB URL
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    // Budget distribution constants
    private static final double HOTEL_PERCENTAGE = 0.5;
    private static final double TRANSPORTATION_PERCENTAGE = 0.3;
    private static final double EVENT_PERCENTAGE = 0.2;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String guestCount = request.getParameter("guestCount");
        String city = request.getParameter("city");
        String budgetStr = request.getParameter("budget");
        String bookingDate = request.getParameter("bookingDate");

        double totalBudget = Double.parseDouble(budgetStr);
        double hotelBudget = totalBudget * HOTEL_PERCENTAGE; // 50% for hotel
        double transportationBudget = totalBudget * TRANSPORTATION_PERCENTAGE; // 30% for transportation
        double eventBudget = totalBudget * EVENT_PERCENTAGE; // 20% for events

        String hotel = null;
        String transportation = null;
        String event = null;
        double totalCost = 0.0;

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // Fetch hotel
            String hotelQuery = "SELECT hotel_name, price_per_night FROM hotels WHERE city_id = ? AND price_per_night <= ? ORDER BY price_per_night DESC LIMIT 1";
            try (PreparedStatement hotelStmt = conn.prepareStatement(hotelQuery)) {
                hotelStmt.setString(1, city);
                hotelStmt.setDouble(2, hotelBudget);
                ResultSet hotelRs = hotelStmt.executeQuery();
                if (hotelRs.next()) {
                    hotel = hotelRs.getString("hotel_name");
                    totalCost += hotelRs.getDouble("price_per_night");
                }
            }

            // Fetch transportation
            String transportQuery = "SELECT transport_type, price FROM transportation WHERE city_id = ? AND price <= ? ORDER BY price DESC LIMIT 1";
            try (PreparedStatement transportStmt = conn.prepareStatement(transportQuery)) {
                transportStmt.setString(1, city);
                transportStmt.setDouble(2, transportationBudget);
                ResultSet transportRs = transportStmt.executeQuery();
                if (transportRs.next()) {
                    transportation = transportRs.getString("transport_type");
                    totalCost += transportRs.getDouble("price");
                }
            }

            // Fetch event
            String eventQuery = "SELECT event_name, price FROM events WHERE city_id = ? AND price <= ? ORDER BY price DESC LIMIT 1";
            try (PreparedStatement eventStmt = conn.prepareStatement(eventQuery)) {
                eventStmt.setString(1, city);
                eventStmt.setDouble(2, eventBudget);
                ResultSet eventRs = eventStmt.executeQuery();
                if (eventRs.next()) {
                    event = eventRs.getString("event_name");
                    totalCost += eventRs.getDouble("price");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred while retrieving available packages. Please try again.");
        }

        // Set attributes for display on the results page
        request.setAttribute("guestCount", guestCount);
        request.setAttribute("city", city);
        request.setAttribute("totalBudget", budgetStr);
        request.setAttribute("bookingDate", bookingDate);
        request.setAttribute("hotel", hotel != null ? hotel : "No available hotels within the budget");
        request.setAttribute("transportation", transportation != null ? transportation : "No available transportation within the budget");
        request.setAttribute("event", event != null ? event : "No available events within the budget");
        request.setAttribute("totalCost", totalCost); // Set the total cost for the JSP

        // Forward to AvailablePackages.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("AvailablePackages.jsp");
        dispatcher.forward(request, response);
    }
}
