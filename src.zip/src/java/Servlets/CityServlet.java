import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CityServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<String> cities = new ArrayList<>();

        // Database connection details
        String dbUrl = "jdbc:mysql://localhost:3306/event_booking_system";
        String dbUser = "root";
        String dbPassword = "password";

        try {
            Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            String sql = "SELECT city_name FROM Cities";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                cities.add(rs.getString("city_name"));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Ensure cities list is passed, even if empty
        if (cities.isEmpty()) {
            cities.add("No cities available");  // Optional: placeholder for empty list
        }
        request.setAttribute("cities", cities);

        // Forward to bookingForm.jsp
        request.getRequestDispatcher("bookingForm.jsp").forward(request, response);
    }
}
