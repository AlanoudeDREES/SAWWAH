
package Servlets;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ConfirmPaymentServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/sawwah";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    HttpSession session = request.getSession();
    String userEmail = (String) session.getAttribute("userEmail");

    if (userEmail == null) {
        response.sendRedirect("Login.jsp");
        return;
    }

    String cardNumber = request.getParameter("cardNumber");
    String expiryDate = request.getParameter("expiryDate");
    String cvv = request.getParameter("cvv");
    String totalCost = request.getParameter("totalCost");
    String eventId = request.getParameter("event_id");
    String hotelId = request.getParameter("hotel_id");
    String transportId = request.getParameter("transport_id");
    String guestCount = request.getParameter("guest_count");
    String budget = request.getParameter("budget");

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        // Insert into bookings table
        String bookingInsertSQL = "INSERT INTO bookings (user_id, event_id, hotel_id, transport_id, guest_count, budget, total_cost) VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement bookingStmt = conn.prepareStatement(bookingInsertSQL, PreparedStatement.RETURN_GENERATED_KEYS);

        // Set parameters for the booking
        bookingStmt.setInt(1, getUserId(userEmail, conn));
        bookingStmt.setInt(2, Integer.parseInt(eventId));
        bookingStmt.setInt(3, Integer.parseInt(hotelId));
        bookingStmt.setInt(4, Integer.parseInt(transportId));
        bookingStmt.setInt(5, Integer.parseInt(guestCount));
        bookingStmt.setBigDecimal(6, new BigDecimal(budget));
        bookingStmt.setBigDecimal(7, new BigDecimal(totalCost));

        bookingStmt.executeUpdate();

        // Get the generated booking ID
        ResultSet generatedKeys = bookingStmt.getGeneratedKeys();
        int bookingId = 0;
        if (generatedKeys.next()) {
            bookingId = generatedKeys.getInt(1);
        }

        // Insert into payments table
        String paymentInsertSQL = "INSERT INTO payments (booking_id, cardholder_name, card_number, expiration_date, cvv, status) VALUES (?, ?, ?, ?, ?, 'Success')";
        PreparedStatement paymentStmt = conn.prepareStatement(paymentInsertSQL);
        paymentStmt.setInt(1, bookingId);
        paymentStmt.setString(2, userEmail); // Assuming the cardholder's name is the user's email
        paymentStmt.setString(3, cardNumber);
        paymentStmt.setDate(4, java.sql.Date.valueOf(expiryDate));
        paymentStmt.setString(5, cvv);

        paymentStmt.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
        
    }

    response.sendRedirect("PaymentSuccess.jsp");
}

    private boolean processPayment(String cardNumber, String expiryDate, String cvv, String totalCost) {
       
        if (cardNumber.length() != 16 || !cardNumber.matches("\\d{16}")) {
            return false; // Invalid card number
        }
        if (cvv.length() != 3 || !cvv.matches("\\d{3}")) {
            return false; // Invalid CVV
        }

        return true;
    }

    private int getUserId(String userEmail, Connection conn) {
        int userId = -1; // Default value indicating not found
        String userIdQuery = "SELECT user_id FROM users WHERE email = ?"; // Assuming a 'users' table with an 'id' and 'email' field
        try (PreparedStatement stmt = conn.prepareStatement(userIdQuery)) {
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                userId = rs.getInt("user_id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userId;
    }
}