package Servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");

        // Database connection variables
        String jdbcURL = "jdbc:mysql://localhost:3306/sawwah";
        String dbUser = "root"; 
        String dbPassword = "root"; 

        // SQL queries
        String checkUserSql = "SELECT * FROM users WHERE email = ?";
        String insertUserSql = "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)";

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Check if user already exists
            PreparedStatement checkStatement = connection.prepareStatement(checkUserSql);
            checkStatement.setString(1, email);
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                // User already exists, redirect to error page or show alert
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<script type=\"text/javascript\">");
                out.println("alert('User already registered with this email. Please try logging in.');");
                out.println("location='SignUp.jsp';");
                out.println("</script>");
            } else {
                // If user doesn't exist, proceed with registration
                PreparedStatement insertStatement = connection.prepareStatement(insertUserSql);
                insertStatement.setString(1, name);
                insertStatement.setString(2, email);
                insertStatement.setString(3, phone);
                insertStatement.setString(4, password);

                int rowsInserted = insertStatement.executeUpdate();
                if (rowsInserted > 0) {
                    response.sendRedirect("success.jsp"); // Redirect to a success page
                }
            }

            // Close resources
            resultSet.close();
            checkStatement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp"); // Redirect to an error page
        }
    }
}
