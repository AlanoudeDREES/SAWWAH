package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BookingFormServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Simply redirect to booking form page if accessed with GET
        response.sendRedirect("bookingForm.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
        // Check if the user is logged in
        String userEmail = (session != null) ? (String) session.getAttribute("userEmail") : null;
        
        if (userEmail == null) {
            // Redirect to login page if user is not logged in
            response.sendRedirect("Login.jsp");
            return;
        }
        
        // Get form parameters
        String guestCount = request.getParameter("guestCount");
        String city = request.getParameter("city");
        String budget = request.getParameter("budget");
        String bookingDate = request.getParameter("bookingDate");
        
        // Set these parameters as request attributes
        request.setAttribute("guestCount", guestCount);
        request.setAttribute("city", city);
        request.setAttribute("budget", budget);
        request.setAttribute("bookingDate", bookingDate);
        
        // Forward to the AvailablePackagesServlet
        request.getRequestDispatcher("AvailablePackagesServlet").forward(request, response);
    }
}
